/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function calcularDia()
{
    var diaUser;
    diaUser = prompt("Introdueix el dia en format XXXX/XX/XX");
    var error;
    error = controlError(diaUser);
    if (!error)
   {     
    var diaUsuari = new Date(diaUser);
    var diaActual = new Date();

    var Resta;
    
    diaActual = diaActual.getTime();
    diaUsuari = diaUsuari.getTime();
    Resta = diaActual - diaUsuari;
    
    Resta = Math.floor(Resta/86400000);
    
    alert(Resta);
    diaUsuari = new Date(diaUser);
    alert(diaUsuari);
   }

}
function controlError(diaUser)
{
 diaUser = diaUser.split("/");
    
    switch (diaUser[1])
    {
       case "01":
       case "03":
       case "05":
       case "07":
       case "08":
       case "10":
       case "12":
                    if (((diaUser[2] < 0) || (diaUser[2]>31)))
                    {
                        alert("El numero de dia introduit es erroni! el mes " + diaUser[1] + " te 31 dies");
                        return true;
                    }
      break;
      case "04":
      case "06":
      case "09":
      case "11":
                              if (((diaUser[2] < 0) || (diaUser[2]>30)))
                    {
                        alert("El numero de dia introduit es erroni! el mes" + diaUser[1] + "te 30 dies");
                        return true;
                    }
       break;
       
    }
    if ((diaUser[1]< 0) || (diaUser[1] > 12))
    {
         alert("El numero de mes introduit es erroni!");
         return true;
    }
    if ((diaUser[0] % 4 === 0 && diaUser[0] % 100 !== 0) || (diaUser[0] % 400 === 0)){
       if (diaUser[1] === "02")
           {
               if((diaUser[2] > 29) || (diaUser[2] < 0))
                   {
                      alert("El año es bisiesto por lo tanto febrero no tiene mas de 29 dias!");
                      return true;
                   }
           }
    }
    else {
           if (diaUser[1] === "02")
           {
               if((diaUser[2] > 28) || (diaUser[2] < 0))
                   {
                      alert("El año no es bisiesto por lo tanto febrero no tiene mas de 28 dias!");
                      return true;
                   }
           }
    }
}
