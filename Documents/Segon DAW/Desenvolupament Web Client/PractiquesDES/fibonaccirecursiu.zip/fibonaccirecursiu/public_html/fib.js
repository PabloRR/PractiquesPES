/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    var n;
    n = prompt("introduce n ");


    function fib(n){

           
        if (n===0) return 0;
        if (n===1) return 1;
        
        return fib(n-1)+fib(n-2);
    }

alert("Resultat " + fib(n));
