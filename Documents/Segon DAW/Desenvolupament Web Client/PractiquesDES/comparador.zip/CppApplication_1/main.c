/* 
 * File:   main.c
 * Author: Carles
 *
 * Created on 1 de septiembre de 2013, 18:28
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    
    
    printf ("hello");
    return (EXIT_SUCCESS);
}

