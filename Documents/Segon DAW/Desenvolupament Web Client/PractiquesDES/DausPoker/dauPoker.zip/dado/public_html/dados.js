/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



function tirarDau()
{
    var dau = new Array();
    
    for (var count = 0; count < 5; count++)
    {
    dau[count] = Math.floor((Math.random()*6)+1);
    }
    for (var count = 0; count < 5; count++)
    {

        switch (dau[count])
        {
            case 1:
                dau[count] = "A";
                break;
            case 2:
            dau[count] = "9(Negre)";
            break;
            case 3:
                dau[count] = "10(Vermell)";
            break;
            case 4:
                dau[count] ="J(Negre)";
            break;
            case 5:
              dau[count] = "Q(Negre)";
            break;
            case 6:
             dau[count] = "K(Vermella)";
        }
    }
    var resultat = dau[0];
        for (var count = 1; count < 5; count++)
    {
    resultat + dau[count];
    }
    
    alert(dau);
}
