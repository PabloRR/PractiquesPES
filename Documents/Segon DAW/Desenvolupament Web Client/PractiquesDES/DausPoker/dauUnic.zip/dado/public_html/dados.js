/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



function tirarDau()
{
    var dau;
    dau = Math.floor((Math.random()*6)+1);
    alert(dau);
}
