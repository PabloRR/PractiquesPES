/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



function tirarDau()
{
    var dau;
    

    dau = Math.floor((Math.random()*6)+1);
    
        switch (dau)
        {
            case 1:
                dau = "A";
                break;
            case 2:
            dau = "9(Negre)";
            break;
            case 3:
                dau = "10(Vermell)";
            break;
            case 4:
                dau ="J(Negre)";
            break;
            case 5:
              dau = "Q(Negre)";
            break;
            case 6:
             dau = "K(Vermella)";
        }
    
    alert(dau);
}
