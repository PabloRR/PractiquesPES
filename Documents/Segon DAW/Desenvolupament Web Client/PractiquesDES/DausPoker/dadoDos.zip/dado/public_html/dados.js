/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



function tirarDau()
{
    var dau = new Array();
    
    for (var count = 0; count < 2; count++)
    {
    dau[count] = Math.floor((Math.random()*6)+1);
    }
    var resultat = dau[0];
        for (var count = 1; count < 2; count++)
    {

    resultat + "i" +  dau[count];
    }
    alert(dau);
}
