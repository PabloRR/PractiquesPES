/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

var n;
var m;



function ackerman(m, n)
{
    if (m === 0)
        {
            return n+1;
        }
    if ((m>0) && (n===0))
        {
            return ackerman(m-1,1);
        }
    if ((m>0)&&(n>0))
        {
            return ackerman(m-1, ackerman(m, n-1));
        }
}
m = Number(prompt("Introdueix valor de m")).valueOf();
n = Number(prompt("Introdueix valor de n")).valueOf();
alert(ackerman(m,n));
