/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
            function calcular(){
                var copsContats = prompt('Escriu quants vols contar');
                if (copsContats === 1)
                    {
                        alert("El numero es 0");
                    }
               else if (copsContats === 2)
                   {
                       alert("Els numeros són 0,1");
                   }
               else if (copsContats > 2)
                   {
                       var contador;
                       var total=0;
                       var numanterior=1;
                       var NumMesAnterior=0;
                       var totalFinal;
                     for (contador = 2; contador<copsContats; contador++)
                     {
                         
                         totalFinal = numanterior+NumMesAnterior;
                         
                         NumMesAnterior=numanterior;
                         numanterior= totalFinal;
                         total = total + "," + totalFinal;
                         
                     }
                     alert(total);
                   }
                   }

