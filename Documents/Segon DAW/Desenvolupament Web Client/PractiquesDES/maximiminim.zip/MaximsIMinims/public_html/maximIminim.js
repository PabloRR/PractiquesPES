/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function maximIminim()//La funció retornara alerts amb els MAX_VALUE, MIN_VALUE y els mateixos multiplicats
{
    var num;
    num = Number.MAX_VALUE;
    alert("Max value" + num);
    num = Number.MIN_VALUE;
    alert("Min value" + num);
    var mult;
    mult = Number.MAX_VALUE * Number.MAX_VALUE;
    alert("Multiplicar valor maxim " + mult);
    mult = Number.MIN_VALUE * Number.MIN_VALUE;
    alert("Multiplicar valor minim " + mult);
    
}
